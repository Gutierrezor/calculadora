import javax.swing.*;
import java.awt.*;

public class operaciones {
    double number1 = 0.0;
    double number2 = 0;
    double resultado = 0.0;

    public operaciones() {
    }

    public void suma() {
        this.number1 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.number2 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.resultado = this.number1 + this.number2;
        JOptionPane.showMessageDialog((Component)null, "El resultado de la suma es" + this.resultado);
    }

    public void resta() {
        this.number1 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.number2 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.resultado = this.number1 - this.number2;
        JOptionPane.showMessageDialog((Component)null, "El resultado de la resta es" + this.resultado);
    }

    public void multiplicacion() {
        this.number1 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.number2 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.resultado = this.number1 * this.number2;
        JOptionPane.showMessageDialog((Component)null, "El resultado de la multiplicacion es" + this.resultado);
    }


    public void division() {
        this.number1 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.number2 = Double.parseDouble(JOptionPane.showInputDialog("Digite el valor"));
        this.resultado = this.number1 / this.number2;
        JOptionPane.showMessageDialog((Component)null, "El resultado de la division es" + this.resultado);
    }

}
