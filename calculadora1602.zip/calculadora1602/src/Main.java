import javax.swing.*;
import java.awt.*;

public class Main {
    static int option;
    static String menu;

    public Main() {
    }

    public static void main(String[] args) {
        operaciones object = new operaciones();

        do {
            menu = JOptionPane.showInputDialog("MENU PRINCIPAL\n1. Suma\n2. Resta\n3. multiplicacion\n4 division");
            option = Integer.parseInt(menu);
            switch (option) {
                case 1:
                    object.suma();
                    break;
                case 2:
                    object.resta();
                    break;
                case 3:
                    object.multiplicacion();
                    break;
                case 4:
                    object.division();

            }
        } while(option != 4);

    }
}
